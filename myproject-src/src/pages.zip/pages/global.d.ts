declare interface Window {
    pywebview: any
}